# My New Portfolio!

Check back soon for my new revised portfolio, which will feature

1. Real time communication

2. A frameworkless, jqueryless, bootstrapless YET responsive front-end.

3. A look at some of my recent work.

4. Maybe some interesting animations.


